const mongoose = require('mongoose');
const { stringify } = require('querystring');


var scheme = new mongoose.Schema({
    name: {
        type: String,
        required: true
    },
    email: {
        type: String,
        required: true,
        unique: true
    },
    mobile: {
        type: Number,
        require: true
    },
    gender: String,
    status: String,
})

const Userdb = mongoose.model('userdb', scheme);

module.export = Userdb;